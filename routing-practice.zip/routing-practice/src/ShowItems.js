import { useParams } from "react-router-dom";
 
const ShowItems=()=>
{
 
 let {itemCode,name,price,quantity,city}=useParams()

return(<>
 
 <h1> {itemCode}</h1>
 <h1> {name}</h1>
 <h1> {price}</h1>
 
</>)
 
}
export default ShowItems