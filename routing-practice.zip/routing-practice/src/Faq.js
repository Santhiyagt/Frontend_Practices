const Faq=()=>{
    return(
        <>
        <h2>What is the name of your company? </h2>
         <h2>My Company name is San Productions </h2>
        </>
    )}
    export default Faq 