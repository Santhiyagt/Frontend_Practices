import { useNavigate } from "react-router-dom"

const Contact=()=>{
    const nav = useNavigate()
      const opensignIn=()=>
      {
        nav("/login")
      }
    return(
        <>
        <h1> Contact</h1>
        <h2>Santhiyagt210@gmail.com</h2>
        <h2>7094253351</h2>

        <button onClick={opensignIn}> Sign In </button>
        </>
    )}
    export default Contact