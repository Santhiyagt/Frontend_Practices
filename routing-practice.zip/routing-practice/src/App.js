import { Link, Route, Routes } from 'react-router-dom';
import './App.css';
import Home from './Home';
import Contact from './Contact';
import Faq from './Faq';
import Login from './Login';
import Welcome from './Welcome';

import { useState } from 'react';
import UCard from './UCard';
import ShowU from './ShowU';
import Details from './Details';
import Electronics from './Electronics';
import ShowItems from './ShowItems';
import Protected from './Protected';
 
function App() {
 

 
  return (
    <div>
 
 
 
 
 
 
 
 
 
<table border="2"> <tr>
  <Link to="/"> <td> Home</td></Link>
   <Link to="/faq">    <td>FAQ</td></Link>
 
   <Link to="/contact"> <td>Contact</td></Link>
 
   
      <Link to="/login"> <td>Login</td></Link>
      
      <Link to="/details"> <td>Details</td></Link>
       <Link to="/Electronics"> <td>Electronics</td></Link>
 
   </tr></table>
 <Routes>
   <Route path="/" element={<Home />} />
    <Route path="/faq" element={<Protected Component={Faq} />} />
     <Route path="/contact" element={<Contact />} />
      <Route path="/login" element={<Login />} />
       <Route path="/welcome" element={<Welcome/>} />

    <Route path="/ucard/:UserId/:Name/:Salary" element={<ShowU />} />
      <Route path="/Details" element={<Details />} />
     
      <Route path="/electronics" element={<Electronics/>}/>
      <Route path="/electitems/:itemcode/:name/:price/:quantity/:city" element={<ShowItems/>} />
 </Routes>
   
   
   
 
 
 
   
    </div>
  );
}
 
export default App;
 