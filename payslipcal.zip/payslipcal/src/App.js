import React from "react";
import { Routes, Route } from "react-router-dom";
import Home from "./Home";
import Form from "./Form";
import Payslip from "./Payslip";

const App = () => {
  return (
    
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/form" element={<Form />} />
        <Route path="/payslip" element={<Payslip />} />
      </Routes>
   
  );
};

export default App;
