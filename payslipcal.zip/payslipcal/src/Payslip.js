import React from "react";
import { useLocation, useNavigate } from "react-router-dom";

const Payslip = () => {
  const { state } = useLocation();
  const nav = useNavigate();

  if (!state) {
    nav("/");
    return null;
  }

  const { name, id, basic } = state;
  const bonus = basic <= 5000 ? basic * 0.05 : basic * 0.1;
  const total = basic + bonus;

  return (
    <div>
      <h2>Show Payslip</h2>
      <p><b>Name:</b> {name}</p>
      <p><b>ID:</b> {id}</p>
      <p><b>Basic Salary:</b> ₹{basic}</p>
      <p><b>Bonus:</b> ₹{bonus}</p>
      <p><b>Total Salary:</b> ₹{total}</p>
    </div>
  );
};

export default Payslip;
