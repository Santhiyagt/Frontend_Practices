import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const Form = () => {
  const [name, setName] = useState("");
  const [id, setId] = useState("");
  const [basic, setBasic] = useState("");
  const nav = useNavigate();

  const handleSubmit = () => {
    nav("/payslip", {
      state: {
        name,
        id,
        basic: parseFloat(basic)
      }
    });
  };

  return (
    <div>
      <h2>Payslip Calculator</h2>
      <input placeholder="Name" onChange={(e) => setName(e.target.value)} /><br />
      <input placeholder="ID" onChange={(e) => setId(e.target.value)} /><br />
      <input placeholder="Basic Salary" onChange={(e) => setBasic(e.target.value)} /><br />
      <button onClick={handleSubmit}>Submit</button>
    </div>
  );
};

export default Form;
