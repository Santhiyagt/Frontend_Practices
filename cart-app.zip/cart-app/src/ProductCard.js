const ProductCard = ({ name, price, image, onAdd }) => {
  return (
    <div style={{ border: "1px solid black", padding: 10, margin: 10 }}>
      <img src={image} alt={name} width={150} height={150} />
      <h3>{name}</h3>
      <p>Price: ₹{price}</p>
      <button onClick={onAdd}>Add to Cart</button>
    </div>
  );
};

export default ProductCard;
