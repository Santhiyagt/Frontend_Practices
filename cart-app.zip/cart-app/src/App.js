import FlowerList from "./FlowerList";
import WatchList from "./WatchList";
import Billing from "./Billing";

const App = () => {
  return (
    <div>
      <h1>Product Store</h1>
      <FlowerList />
      <WatchList />
      <Billing />
    </div>
  );
};

export default App;
