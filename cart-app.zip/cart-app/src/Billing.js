import { useSelector } from "react-redux";

const Billing = () => {
  const { cartItems } = useSelector((state) => state.cart);

  let total = 0;

  return (
    <div>
      <h2>🧾 Bill Summary</h2>
      {cartItems.map((item, index) => {
        total += item.price;
        return (
          <div key={index}>
            <p>{item.name} - ₹{item.price}</p>
          </div>
        );
      })}
      <hr />
      <h3>Total: ₹{total}</h3>
    </div>
  );
};

export default Billing;
