// App.js
import React from "react";
import { BrowserRouter, Link } from "react-router-dom";
import Route from "./Route";

const App = () => {
  return (
    <BrowserRouter>
      <div>
        <h1>📖 Library Management System</h1>

        
        <nav>
          <Link to="/">Home</Link> |{" "}
          <Link to="/signin">Sign In</Link> |{" "}
          <Link to="/signup">Sign Up</Link> |{" "}
          <Link to="/dashboard">Dashboard</Link> |{" "}
          <Link to="/addbook">Add Book</Link> |{" "}
          <Link to="/removebook">Remove Book</Link>
        </nav>

        <hr />

        
        <Route />
      </div>
    </BrowserRouter>
  );
};

export default App;
