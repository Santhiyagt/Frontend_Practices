import React from 'react';

const Dashboard = () => {
  return (
    <div>
      <h2>📚 Dashboard</h2>
      <button>Issue Book</button>
      <button style={{ marginLeft: '10px' }}>Return Book</button>
    </div>
  );
};

export default Dashboard;