
import React from 'react';

const Product = ({ id, title, category, price, thumbnail }) => {
  return (
    <div className="card">
      <img src={thumbnail} alt={title} />
      <h3>{title}</h3>
      <p><strong>Price:</strong> ${price}</p>
      <p><strong>Category:</strong> {category}</p>
      <p><strong>ID:</strong> {id}</p>
    </div>
  );
};

export default Product;
