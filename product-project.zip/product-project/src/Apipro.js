import { useEffect, useState } from "react";
import Product from "./Product";
import "./App.css";

const Apipro = () => {
  let [pro, setPro] = useState([]);
  let [fpro, setFpro] = useState([]);
  let [search, setSearch] = useState("");

  let [category, setCategory] = useState("");
  let [title, setTitle] = useState("");
  let [price, setPrice] = useState("");
  let [thumbnail, setThumbnail] = useState("");

  let [cart, setCart] = useState([]);

  const handleSearch = (e) => setSearch(e.target.value);
  const handleCategory = (e) => setCategory(e.target.value);
  const handleTitle = (e) => setTitle(e.target.value);
  const handlePrice = (e) => setPrice(e.target.value);
  const handleThumbnail = (e) => setThumbnail(e.target.value);

  const addData = () => {
    let data = {
      id: pro.length + 1,
      title,
      category,
      price,
      thumbnail
    };
    setPro([data, ...pro]);
    setCategory("");
    setTitle("");
    setPrice("");
    setThumbnail("");
  };

  const addToCart = (item) => {
    setCart([...cart, item]);
  };

  useEffect(() => {
    fetch("https://dummyjson.com/products")
      .then((res) => res.json())
      .then((temp) => setPro(temp.products))
      .catch((e) => console.log(e));
  }, []);

  useEffect(() => {
    let data = pro.filter((temp) => {
      const titleMatch = temp.title.toLowerCase().includes(search.toLowerCase());
      const categoryMatch = temp.category.toLowerCase().includes(search.toLowerCase());
      return titleMatch || categoryMatch;
    });
    setFpro(data);
  }, [search, pro]);

  return (
    <>
      <input
        placeholder="Search by category or title"
        onChange={handleSearch}
        value={search}
      />

      <div className="cont">
        <input placeholder="Enter category" value={category} onChange={handleCategory} />
        <input placeholder="Enter title" value={title} onChange={handleTitle} />
        <input placeholder="Enter image URL" value={thumbnail} onChange={handleThumbnail} />
        <input placeholder="Enter price" value={price} onChange={handlePrice} />
        <button onClick={addData}>Add item</button>
      </div>

      <h3>All Products</h3>
      {(search.length > 0 ? fpro : pro).map((p) => (
        <Product
          key={p.id}
          id={p.id}
          title={p.title}
          category={p.category}
          price={p.price}
          thumbnail={p.thumbnail}
          addToCart={() => addToCart(p)}
        />
      ))}

      <h3>🛒 Cart Items</h3>
      {cart.length === 0 ? (
        <p>No items in cart.</p>
      ) : (
        cart.map((item, index) => (
          <div key={index} className="card">
            <h4>{item.title}</h4>
            <p>Price: ${item.price}</p>
            <p>Category: {item.category}</p>
          </div>
        ))
      )}
    </>
  );
};

export default Apipro;
