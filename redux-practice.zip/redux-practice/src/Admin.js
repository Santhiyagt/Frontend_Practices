import { useDispatch, useSelector } from "react-redux";
import { issueBookdsa, returnBookdsa, issueBookjava, returnBookjava,} from "./BookSlice";

const Admin = () => {
  const dispatch = useDispatch();
  const { dsa, java } = useSelector((state) => state.book);

  return (
    <div>
     
      <p>Java Books Available: {java}</p>
      <p>DSA Books Available: {dsa}</p>

      <button onClick={() => dispatch(issueBookjava())}>Issue Java Book</button>
      <button onClick={() => dispatch(returnBookjava())}>Return Java Book</button>
      <button onClick={() => dispatch(issueBookdsa())}>Issue DSA Book</button>
      <button onClick={() => dispatch(returnBookdsa())}>Return DSA Book</button>
    </div>
  );
};

export default Admin;